[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/Zw5llIO3)
# CompSci 351 / CompSt 751 Homework Assignment 6

This is a homework assignment at University of Wisconsin-Milwaukee.

## Planning: Due Friday 10pm

### Focus

#### What is this homework assignment about?
this assignment is about a cyclic linkedlist with dummy at the beginning/end of the list, and intrestingly here the dummynode is not null, and also we have an iterator with 2 pointers cur and next
### Gather

#### What do I know?  What do I need to know that's new?
i know how to manipulate the acyclic linkedlist with iterator but i am not sure how things go with cyclic and the role of iterator sounds a bit tricky compared to previous assignment and i am not familiar with generics
### Brainstorm

#### What are some ideas for solving this homework assignment?
i am actually planning to work on thorough reading of documentantion and then work on the things that needs to be done instead of wasting most of my time in debugging and imlementing the methods wrongly and finally optimize my code for efficiency
### Plan

#### What will I work on first after I finish this planning part?
1st i will be planning on implementing node class and resolve complinig errors and then work on wellformed and then work on remove and clone method and start working on errors and imrove my  code to pass the efficiency test cases aswell

*The preceding steps should be completed and committed by the
Friday 10pm deadline.*

## Reflection: Due Monday 10pm

### Review

#### Did I correctly anticipate the difficulties?

#### How did the plan go?

### Preview

#### What should I do differently for next week's homework assignment?

#### Do I need more resources?

## Optional Feedback

### Comments (optional)

#### Here are my comments on the assignment to the course instructors:

### Check in (optional)

#### How am I feeling about the assignment and this course?
