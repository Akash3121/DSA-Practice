[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/2NBAP26q)
# CompSci 351 / CompSt 751 Homework Assignment 3

This is a homework assignment at University of Wisconsin-Milwaukee.

## Planning: Due Friday 10pm

### Focus

#### What is this homework assignment about?
the assignment involves creating a dynamic array data structure using the AbstractCollection 
### Gather

#### What do I know?  What do I need to know that's new?
this has 2 wellformed simillar to the homework 2 and i will be using iterators
### Brainstorm

#### What are some ideas for solving this homework assignment?
as to my understanding i understood very little about the homework i will go step by step and put much effort on debugging
### Plan

#### What will I work on first after I finish this planning part?
i have unlcoked the test cases, they were tricky, now i have to start on collection add part and iterators methods and debug 

*The preceding steps should be completed and committed by the
Friday 10pm deadline.*

## Reflection: Due Monday 10pm

### Review

#### Did I correctly anticipate the difficulties?
no i was not able to solve any efficiency tests.
#### How did the plan go?
the plan went really good but i have underestimated the efficiency tests
### Preview

#### What should I do differently for next week's homework assignment?
i have to look up for efficiency tests way before and try writting the code as required as efficency tests parllely
#### Do I need more resources?
i dont think i should have needed more resources for this assignment but should have better understanding for efficiency tests
## Optional Feedback

### Comments (optional)

#### Here are my comments on the assignment to the course instructors:

### Check in (optional)

#### How am I feeling about the assignment and this course?
