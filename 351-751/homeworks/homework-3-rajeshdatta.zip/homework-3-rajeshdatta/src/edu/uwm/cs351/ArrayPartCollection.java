package edu.uwm.cs351;

import java.util.AbstractCollection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.Consumer;

public class ArrayPartCollection extends AbstractCollection<Part> implements Robot, Cloneable// TODO: extends ... implements ...
{ 
	private static final int DEFAULT_INITIAL_CAPACITY = 1;
	
	private static Consumer<String> reporter = (s) -> System.out.println("Invariant error: "+ s);
/**
 *Reports an invariant error.
 *@param error the error message
 *@return always returns false
 */
	private boolean report(String error) {
		reporter.accept(error);
		return false;
	}
	
	private String[] functions;
	private Part[] parts;
	private int size;
	private int version;
	 /**
     * Checks if the collection is well-formed.
     * @return true if the collection is well-formed, false otherwise
     */
	private boolean wellFormed() {
		//TODO: Complete this.  Simpler than than the same for HW 2
		// If no problems discovered, return true
		// 1. The "functions" and "parts" arrays must not be null.
				// TODO
				if (functions == null || parts == null) {
					return report("Functions or Parts must not be null");
				}
				
				// 2. The "functions" and "parts" arrays are always the same length.
				// TODO
				if (functions.length != parts.length) {
					return report("Functions and Parts arrays should be of same length");
				}
				
				// 3. The size cannot be negative or greater than the length of the arrays.
				// TODO
				if (size < 0 || size > functions.length) {
					return report("Size cannot be negative or size must not be greater than length of arrays(functions or parts) => Size is out of bounds");
				}
				// 4. None of the first “size” elements of either array can be null. (ie. no holes)
				// TODO
				for(int i = 0; i < size; i++)	{
					if (functions[i] == null || parts[i] == null) {
						return report("Null element found at index: " + i + " No Holes => none of the first 'size' elements of either array can be null");
					}
				}
				
		return true;
	}
	
	/**
	 * Helper method to grow the arrays so that 
	 * they are at least the length of the capacity needed, and ensures arrays are
	 * the same length with the same entries
	 * @param cap the minimum capacity the arrays need to have
	 */
	private void ensureCapacity(int cap) {
		if (cap <= functions.length) return;
		int newCap = cap;
		if (cap < functions.length*2) newCap = functions.length*2;
		String[] newFunctions = new String[newCap];
		Part[] newParts = new Part[newCap];
		for (int i=0; i < size; ++i) {
			newFunctions[i] = functions[i];
			newParts[i]= parts[i];
		}
		functions = newFunctions;
		parts = newParts;
	}
	
	
	private ArrayPartCollection(boolean ignored) {} // do not change this constructor
	
	/** Construct an array part collection.
	 */
	public ArrayPartCollection(){
		this(DEFAULT_INITIAL_CAPACITY);
	}
	
	/**
	 * Construct an array part collection with the given initial capacity
	 * @param cap initial capacity, must not be negative
	 */
	public ArrayPartCollection(int cap){
		functions = new String[cap];
		parts = new Part[cap];
		assert wellFormed(): "invariant broken by constructor";
	}

	// TODO: All the methods!
	// Make sure to properly document each.
	// You are welcome to copy code in from the solution 
	// to Homework #2, especially if you re-type it yourself!
		
	@Override // decorate
	public ArrayPartCollection clone() {
	    assert wellFormed() : "invariant broken in clone";
	    ArrayPartCollection result;
	    try {
	        result = (ArrayPartCollection) super.clone();

	        // Creating new arrays for parts and functions
	        result.parts = new Part[parts.length];
	        result.functions = new String[functions.length];

	        // Deep copy of each Part object and function
	        for (int i = 0; i < size; i++) {
	            if (parts[i] != null) {
	                result.parts[i] = parts[i];
	                result.functions[i] = functions[i];
	            }
	        }

	    } catch (CloneNotSupportedException e) {
	        throw new AssertionError("forgot to implement cloneable?");
	    }
	    assert result.wellFormed() : "invariant broken in result of clone";
	    assert wellFormed() : "invariant broken by clone";
	    return result;
	}
	
	/**
     * Removes the part associated with the specified function.
     * @param function the function of the part to remove
     * @return the removed part, or null if no such part exists
     */
	@Override
	public Part removePart(String arg0) {
		// TODO Auto-generated method stub
		assert wellFormed() : "Invariant broken before removing part";
		// arg0 is function

	    if (arg0 == null) {
	        if (size > 0) {
	            for (int i = 0; i < size; i++) {
	                if (parts[i] != null) {
	                    Part removedPart = parts[i];
	                    parts[i] = null;
	                    functions[i] = null;
	                    for (int j = i; j < size - 1; j ++) {
		                	functions[j] = functions[j+1];
		                	parts[j] = parts[j+1];
		                }
	                    size --;
	                    version ++;
	                    return removedPart;
	                }
	            }
	        }
	    } else {
	        for (int i = 0; i < size; i++) {
	            if (arg0.equals(functions[i])) {
	                Part removedPart = parts[i];
	                parts[i] = null;
	                functions[i] = null;
	                for (int j = i; j < size - 1; j ++) {
	                	functions[j] = functions[j+1];
	                	parts[j] = parts[j+1];
	                }
	                size --;
	                version ++;
	                return removedPart;
	            }
	        }
	    }
		assert wellFormed() : "Invariant broken before removing part";

		return null; // no part found
	}
	 /**
     * Adds a part with the specified function to the collection.
     * @param function the function of the part
     * @param part the part to add
     * @return true if the part was successfully added, false otherwise
     */
	 
	@Override // implementation
	public boolean addPart(String arg0, Part arg1) {
		// TODO Auto-generated method stub
		// here arg0 is function and arg1 is part
		//assert wellformed
		 assert wellFormed() : "Invariant broken before adding part";
		if (arg0 == null || arg1 == null) {
			throw new NullPointerException("function or part must not be null");
		}
		
		ensureCapacity(size + 1);
		
		functions[size] = arg0;
		parts[size] = arg1;
		
		size ++;
		
		version ++;
		
		assert wellFormed() : "Invariant broken after adding part";
		return true;
	}
/*
 * 	 @param function the function of the part to retrieve, or null to ignore function
	 * @param index the index of the part to retrieve
	 * @return the part associated with the specified function and index,
	 *         or null if no such part exists
	 * @throws IllegalArgumentException if the index is negative
	 */
	@Override
	public Part getPart(String arg0, int arg1) {
		// TODO Auto-generated method stub
		assert wellFormed():"Invariant before getPart ";
		if (arg1 < 0) {
			throw new IllegalArgumentException("Index must be -ve");
		}
		
		if (arg0 == null) {
	        int counter = -1;
	        for (int i = 0; i < size; i++) {
	            if (parts[i] != null) {
	                counter++;
	                if (counter == arg1) {
	                    return parts[i];
	                }
	            }
	        }
	        return null;
	    }

		for (int i = 0; i < size; i++) {
		   if (arg0.equals(functions[i])) {
			   if (arg1 == 0) {
				   return parts[i];
			   }
			   arg1--;
		   }
		}
		assert wellFormed():"Invariant before getPart ";
		return null;
	}

	/**
	 * Inner iterator class to iterate over the parts collection.
	 */
	private class MyIterator implements Iterator<Part>// TODO: implements ...
	{
		int cur, next; 
		int colVersion;
		String function;
		  /**
	     * Checks if the iterator is well-formed.
	     * @return true if the iterator is well-formed, false otherwise
	     */
		private boolean wellFormed() {
			// TODO
			if(!ArrayPartCollection.this.wellFormed()) {
				return false;
			}
			if (version != colVersion) {
				return true;
			}
			
			if (cur < 0 || cur > size) {
				return report("current is out of bounds");
			}
			
			if (next < 0 || next > size  ) {
				return report("next is out of bounds");
			}
			
			if (function != null && cur != size && !functions[cur].equals(function)) {
				return report("function must match with functions cur");
			}
			
			if (function != null && next != size && !functions[next].equals(function)) {
				return report("function must match iwth fiunction");
			}
			
			if (cur > next)	{
				return report("cur must not be greater than next");
			}
			if(function!=null && cur!=size && next!=size) {
				for (int i = cur +1; i < next; i++) {
					if (functions[i].equals(function) && functions[next].equals(function)) {
						return report("dfghjkuyhnmkiuh");
					}
				}
			}
			if (function == null && (cur+1<next )) {
			    return report("function = null and then next != curr");
			}
			return true;
		}
		/**
	     * Constructs a MyIterator object with the given function.
	     * @param func the function to iterate over
	     */
		MyIterator(boolean ignored) {} // do not change this constructor
			

		MyIterator(String func) {
			// TODO: initialize fields
			// (We use a helper method)
			 colVersion = version;
			 function = func;
			 cur = -1;
			 next = -1;
			 
			 if (size == 0) {
				 cur = 0;
				 next = 0;
			 }
			 
			 else if (function == null) {
				 cur = 0;
				 next = 0;
			 }
			 else {
				 
				 for (int i = 0; i < size; i++) {
					 if (function.equals(functions[i])) {
						 cur = i;
						 next = i;
						 break;
					 }
				 }
				if(next < 0)
				{
					cur = size;
					next = size;
				}
			 }
			 
			assert wellFormed() : "iterator constructor didn't satisfy invariant";
		}

		@Override // required
		public boolean hasNext() {
			// TODO Auto-generated met-hod stub
			
			assert wellFormed() : "invariant broke at start of hasNext";
		    
		    if (colVersion != version) {
		        throw new ConcurrentModificationException("Iterator is stale at hasNext");
		    }
		    
		    if (size == 0 || cur > size || next >= size) {
		    	return false;
		    }

		    if (next != size) {
		    	return true;
		    }
		    
		    if (size == 1) {
		    	return false;
		    }
		    
		    assert wellFormed() : "invariant broken in hasNext";
		    return true;
		}

		@Override // required
		public Part next() {
			// TODO Auto-generated method stub
			if (colVersion != version) throw new ConcurrentModificationException("Iterator is stale at Next");
			assert wellFormed() : "invariant broken at next";
			if(!hasNext()) throw new NoSuchElementException("No next element");

			if (function != null) {
				cur = next;

				for (int i = next + 1; i < size; i ++) {
					if (functions[i].equals(function)) {
						next = i;
						return parts[cur];
					} 
				}
			}
			else {
				cur = next;
				next ++;
				return parts[cur];
			}
			next = size;
			assert wellFormed() : "invariant broken in next";
			return parts[cur];
		}
			
//		@Override 
		public void remove() {
			assert wellFormed() : "invariant broken at remove";

			if (colVersion != version) throw new ConcurrentModificationException("Iterator is stale at remove");

			if (functions[cur] == null || parts[cur] == null || cur == next || size == 0) {
				throw new IllegalStateException("function at curr is null");
			}		
			for (int i = cur; i < size - 1; i ++) {
				functions[i] = functions[i + 1];
				parts[i] = parts[i + 1];
			}
			next --;
			cur = next;
			size --;
			version ++;
			colVersion ++;
			assert wellFormed() : "invariant broken in remove";
		}
		

		// TODO: Body of iterator class
	}
		
	public static class Spy {
		/**
		 * Return the sink for invariant error messages
		 * @return current reporter
		 */
		public Consumer<String> getReporter() {
			return reporter;
		}

		/**
		 * Change the sink for invariant error messages.
		 * @param r where to send invariant error messages.
		 */
		public void setReporter(Consumer<String> r) {
			reporter = r;
		}

		/**
		 * Create a testing instance of a dynamic array robot with the given
		 * data structure.
		 * @param f the array of functions
		 * @param p the array of parts
		 * @param s the size
		 * @return a new testing dynamic array robot with this data structure.
		 */
		public ArrayPartCollection newInstance(String[] f, Part[] p, int s, int v) {
			ArrayPartCollection result = new ArrayPartCollection(false);
			result.functions = f;
			result.parts = p;
			result.size = s;
			result.version = v;
			return result;
		}
			
		/**
		 * Creates a testing instance of an iterator
		 * @param outer the ArrayListRobot attached to the iterator
		 * @param f TODO
		 * @param i the starting index
		 * @param n the remaining value, how many elements are left
		 * @param cv the colVersion
		 */
		public Iterator<Part> newIterator(ArrayPartCollection outer, String f, int i, int n, int cv) {
			MyIterator result = outer.new MyIterator(false);
			result.function = f;
			result.cur = i;
			result.next = n;
			result.colVersion = cv;
			return result;
		}
			
		/**
		 * Check the invariant on the given dynamic array robot.
		 * @param r robot to check, must not be null
		 * @return whether the invariant is computed as true
		 */
		public boolean wellFormed(ArrayPartCollection r) {
			return r.wellFormed();
		}
			
		/**
		 * Check the invariant on the given Iterator.
		 * @param it iterator to check, must not be null
		 * @return whether the invariant is computed as true
		 */
		public boolean wellFormed(Iterator<Part> it) {
			MyIterator myIt = (MyIterator)it;
			return myIt.wellFormed();
		}
	}

	@Override
	public Iterator<Part> iterator() {
		// TODO Auto-generated method stub
		return new MyIterator(null); 
	}

	public Iterator<Part> iterator(String arg) {
		// TODO Auto-generated method stub
		return new MyIterator(arg); 
	}
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}
}
	
	

